# YourCloud v5.1 Expert Pass

This pass hardens three areas:
- search quality: pgvector + CLIP + hybrid rerank
- hosted app runtime stability: local Docker sandbox runner with runtime templates and health metadata
- desktop polish: Tauri packaging scaffold + GitHub Actions Windows build

Run:
1. Copy `.env.example` to `.env`
2. `docker compose up --build`
3. Open `https://localhost:8443`
