CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS media_items (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,
  mime_type TEXT NOT NULL DEFAULT '',
  size_bytes BIGINT NOT NULL DEFAULT 0,
  object_key TEXT NOT NULL,
  thumb_object_key TEXT,
  extracted_text TEXT NOT NULL DEFAULT '',
  encryption_iv TEXT NOT NULL,
  encryption_auth_tag TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS media_vectors (
  media_id INTEGER PRIMARY KEY REFERENCES media_items(id) ON DELETE CASCADE,
  embedding vector(512) NOT NULL,
  searchable_text TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS media_vectors_embedding_idx ON media_vectors USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
CREATE TABLE IF NOT EXISTS hosted_apps (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  runtime TEXT NOT NULL DEFAULT 'static',
  file_name TEXT NOT NULL,
  visibility TEXT NOT NULL DEFAULT 'Private',
  domain_name TEXT,
  preview_url TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'staging',
  source_prompt TEXT,
  container_name TEXT,
  health_url TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
