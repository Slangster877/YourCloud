import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { Pool } from 'pg';
dotenv.config();
const pool = new Pool({host:process.env.POSTGRES_HOST||'postgres',port:Number(process.env.POSTGRES_PORT||5432),database:process.env.POSTGRES_DB||'yourcloud',user:process.env.POSTGRES_USER||'yourcloud',password:process.env.POSTGRES_PASSWORD||'yourcloudpass'});
(async()=>{await pool.query('CREATE TABLE IF NOT EXISTS schema_migrations (file_name TEXT PRIMARY KEY, executed_at TIMESTAMP NOT NULL DEFAULT NOW())'); const dir=path.join(process.cwd(),'migrations'); for(const file of fs.readdirSync(dir).filter(f=>f.endsWith('.sql')).sort()){const found=await pool.query('SELECT 1 FROM schema_migrations WHERE file_name=$1',[file]); if(found.rowCount) continue; await pool.query(fs.readFileSync(path.join(dir,file),'utf8')); await pool.query('INSERT INTO schema_migrations (file_name) VALUES ($1)',[file]);} await pool.end();})().catch(err=>{console.error(err);process.exit(1)});
