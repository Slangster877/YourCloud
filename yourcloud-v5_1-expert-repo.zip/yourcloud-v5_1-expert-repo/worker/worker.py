import os, io, base64, tempfile, subprocess
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import Response
from sentence_transformers import SentenceTransformer
from PIL import Image
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import boto3
from pypdf import PdfReader
from pdf2image import convert_from_bytes
import pytesseract
from docx import Document
from openpyxl import load_workbook
from pptx import Presentation
app = FastAPI(); model = SentenceTransformer("clip-ViT-B-32")
s3 = boto3.client("s3", endpoint_url=os.getenv("MINIO_ENDPOINT","http://minio:9000"), aws_access_key_id=os.getenv("MINIO_ROOT_USER","minioadmin"), aws_secret_access_key=os.getenv("MINIO_ROOT_PASSWORD","minioadmin123"))
bucket = os.getenv("MINIO_BUCKET","yourcloud")
master_key = bytes.fromhex(os.getenv("ENCRYPTION_MASTER_KEY"))
def clean_slug(v:str)->str:
 import re
 return re.sub(r"^-+|-+$","", re.sub(r"[^a-z0-9]+","-", v.lower().strip())) or "app"
def infer_kind(mime:str,name:str)->str:
 lower=name.lower()
 if mime.startswith("image/") or lower.endswith((".jpg",".jpeg",".png",".webp",".heic")): return "photo"
 if mime.startswith("video/") or lower.endswith((".mp4",".mov",".avi",".mkv")): return "video"
 return "document"
def encrypt_bytes(data:bytes):
 import os
 iv=os.urandom(12); aes=AESGCM(master_key); encrypted=aes.encrypt(iv,data,None); return encrypted[:-16], iv.hex(), encrypted[-16:].hex()
def decrypt_bytes(data:bytes, iv_hex:str, tag_hex:str):
 aes=AESGCM(master_key)
 return aes.decrypt(bytes.fromhex(iv_hex), data + bytes.fromhex(tag_hex), None)
def image_thumb(buf:bytes):
 img=Image.open(io.BytesIO(buf)).convert("RGB"); img.thumbnail((480,480)); out=io.BytesIO(); img.save(out,format="JPEG",quality=82); return out.getvalue()
def video_thumb(buf:bytes):
 with tempfile.TemporaryDirectory() as td:
  inp=os.path.join(td,"in.mp4"); outp=os.path.join(td,"out.jpg"); open(inp,"wb").write(buf); subprocess.run(["ffmpeg","-y","-i",inp,"-ss","00:00:00.500","-vframes","1",outp],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); return open(outp,"rb").read()
def fallback_thumb():
 img=Image.new("RGB",(600,400),(25,48,95)); out=io.BytesIO(); img.save(out,format="JPEG",quality=82); return out.getvalue()
def pdf_preview_and_text(buf:bytes):
 text=""
 try:
  reader=PdfReader(io.BytesIO(buf))
  for page in reader.pages[:3]: text += " " + (page.extract_text() or "")
 except Exception: pass
 thumb=fallback_thumb()
 try:
  pages=convert_from_bytes(buf, first_page=1, last_page=1)
  if pages:
   img=pages[0].convert("RGB"); img.thumbnail((480,480)); out=io.BytesIO(); img.save(out,format="JPEG",quality=82); thumb=out.getvalue()
   try: text += " " + pytesseract.image_to_string(img)
   except Exception: pass
 except Exception: pass
 return thumb, text.strip()
def docx_text(buf:bytes): return " ".join(p.text for p in Document(io.BytesIO(buf)).paragraphs if p.text).strip()
def xlsx_text(buf:bytes):
 wb=load_workbook(io.BytesIO(buf), read_only=True, data_only=True); rows=[]
 for ws in wb.worksheets[:3]:
  for row in ws.iter_rows(max_row=40, values_only=True): rows.append(" ".join("" if v is None else str(v) for v in row))
 return " ".join(rows).strip()
def pptx_text(buf:bytes):
 prs=Presentation(io.BytesIO(buf)); parts=[]
 for slide in prs.slides[:10]:
  for shape in slide.shapes:
   if hasattr(shape,"text") and shape.text: parts.append(shape.text)
 return " ".join(parts).strip()
@app.post("/embed/text")
async def embed_text(payload:dict): return {"embedding": model.encode(payload.get("text","")).tolist()}
@app.post("/process-upload")
async def process_upload(file:UploadFile=File(...), mimeType:str=Form(...)):
 data=await file.read(); kind=infer_kind(mimeType,file.filename); text=""; thumb=fallback_thumb(); lower=file.filename.lower()
 if kind=="photo":
  thumb=image_thumb(data)
  try: text=pytesseract.image_to_string(Image.open(io.BytesIO(data)))
  except Exception: text=""
  embedding=model.encode(Image.open(io.BytesIO(thumb)).convert("RGB")).tolist()
 elif kind=="video":
  try: thumb=video_thumb(data)
  except Exception: thumb=fallback_thumb()
  embedding=model.encode(Image.open(io.BytesIO(thumb)).convert("RGB")).tolist()
 else:
  if lower.endswith(".pdf") or mimeType=="application/pdf": thumb,text=pdf_preview_and_text(data)
  elif lower.endswith(".docx"): text=docx_text(data)
  elif lower.endswith(".xlsx"): text=xlsx_text(data)
  elif lower.endswith(".pptx"): text=pptx_text(data)
  elif mimeType.startswith("text/") or lower.endswith((".txt",".md",".csv",".json",".html",".js")): text=data.decode("utf-8",errors="ignore")[:30000]
  embedding=model.encode(f"{file.filename} {text}").tolist()
 encrypted,iv,auth_tag=encrypt_bytes(data); slug=clean_slug(file.filename)
 return {"kind":kind,"object_key":f"media/{slug}-{os.urandom(4).hex()}","thumb_object_key":f"thumbs/{slug}-{os.urandom(4).hex()}.jpg","thumb_jpg":base64.b64encode(thumb).decode(),"encrypted":base64.b64encode(encrypted).decode(),"iv":iv,"auth_tag":auth_tag,"extracted_text":text,"embedding":embedding,"searchable_text":f"{file.filename} {mimeType} {kind} {text}".strip()}
@app.post("/store-upload")
async def store_upload(payload:dict):
 s3.put_object(Bucket=bucket, Key=payload["object_key"], Body=base64.b64decode(payload["encrypted"]), ContentType="application/octet-stream")
 s3.put_object(Bucket=bucket, Key=payload["thumb_object_key"], Body=base64.b64decode(payload["thumb_jpg"]), ContentType="image/jpeg")
 return {"ok":True}
@app.post("/decrypt-media")
async def decrypt_media(payload:dict):
 obj=s3.get_object(Bucket=bucket, Key=payload["object_key"]); data=obj["Body"].read(); plain=decrypt_bytes(data,payload["iv"],payload["auth_tag"]); return Response(content=plain, media_type=payload.get("mime_type","application/octet-stream"))
